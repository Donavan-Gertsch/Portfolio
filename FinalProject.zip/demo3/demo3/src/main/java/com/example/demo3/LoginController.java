package com.example.demo3;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;

public class LoginController{
    @FXML
    private TextField InputUsername;

    @FXML
    private AnchorPane loginAnchorPane;

    @FXML
    private TextField InputPassword;

    @FXML
    private Button LoginButton;

    @FXML
    private Button CreateButton;

    @FXML
    public void createControl(MouseEvent event) {
        Stage stage = (Stage) CreateButton.getScene().getWindow();
        stage.close();
    }

    @FXML
    void loginControl(MouseEvent event) throws SQLException {
        CurrEmployee();
    if(InputUsername.getText().isBlank() == false && InputPassword.getText().isBlank() == false) {
        validateLogin();

    }
    else {


        }
    }

    public void validateLogin(){
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        String verifyLogin = "SELECT count(1) FROM UserAccounts WHERE Username = '" + InputUsername.getText() + "' AND password = '" + InputPassword.getText() + "'";

        try {
            Statement statement = connectDB.createStatement();
            ResultSet queryResult = statement.executeQuery(verifyLogin);

            while(queryResult.next()) {
                if(queryResult.getInt(1) == 1){
                new SceneController(loginAnchorPane, "Directory.fxml");
                }else{

                }
            }
        }
        catch(Exception e){
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }

    }
    public static CurrentUser CurrUser = null;
    public void CurrEmployee() throws SQLException {
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();
        String currEmployee = "Select * From useraccounts Where Username = '"+ InputUsername.getText() +"';";
        try {
            Statement statement = connectDB.createStatement();
            ResultSet CurrEmployeeStmt = statement.executeQuery(currEmployee);
            String Username = "";
            double HourlyWage = 0;
            boolean Manager = false;
            while (CurrEmployeeStmt.next()) {
                Username = CurrEmployeeStmt.getString("Username");
                HourlyWage = CurrEmployeeStmt.getDouble("HourlyWage");
                Manager = CurrEmployeeStmt.getBoolean("Manager");
            }
            CurrUser = new CurrentUser(Username, Manager, HourlyWage);
        }
        catch(Exception e){
        System.err.println("Got an exception!");
        // printStackTrace method
        // prints line numbers + call stack
        e.printStackTrace();
        // Prints what exception has been thrown
        System.out.println(e);
    }
    }
}
