function takestep()
{
  var red=parseFloat(document.getElementById('red').value);
  var blue=parseFloat(document.getElementById('blue').value);
  var rlength=parseFloat(document.getElementById('rlength').value);

  var number = Array(1,2,3);
  var rednumber = number[Math.floor(Math.random()*number.length)];
  var bluenumber = number[Math.floor(Math.random()*number.length)];

 
   var red= red+rednumber;
   var blue= blue+bluenumber;
  if(red<=rlength && blue<=rlength){

   document.getElementById("red").value = red;
   document.getElementById("blue").value = blue;
}
else if(red>=rlength && blue>=rlength){
   alert("Race Tied!");
}else{
    if(red=rlength){
        alert("Red dot wins!");
    }else{
        alert("Blue dot wins!")
    }if(red>rlength | blue>rlength){
      alert('The race is over click reset')
    }
}

}
function reset()
{
  document.getElementById("red").value = '0';
  document.getElementById("blue").value = '0';
}