  function rolldice()
  {                                                                    var y = parseFloat(document.getElementById('textbox').value);
   var count = 0;
   var total = 0;
   var x = Math.floor((Math.random() * 6) + 1);
   var final = total/y;
   
  while (count<y)
    {
      var x = Math.floor((Math.random() * 6) + 1);
      
      total = total+x;
      count = count+1;
      var final = total/y;
    }
  document.getElementById('outputDIV').innerHTML= 'The average dice roll was ' + final;
   
  }

                                                