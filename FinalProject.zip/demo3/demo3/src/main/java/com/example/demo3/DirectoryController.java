package com.example.demo3;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.text.DecimalFormat;
import java.util.List;

public class DirectoryController {
    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private AnchorPane directoryAnchorPane;
    @FXML
    private Button timeClock;

    @FXML
    private Button OP;

    @FXML
    private Button Postings;

    @FXML
    private Button ManagerOpt;

    @FXML
    private Button Statistics;

    @FXML
    private Button Inventory;

    @FXML
    private TextField ExistingTextField;

    @FXML
    void orderProducts(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("orderTaker.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void Inventoryclick(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("inventory.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    void RefreshInventory(ActionEvent event) {
            try {
                DatabaseConnection connectNow = new DatabaseConnection();
                Connection connectDB = connectNow.getConnection();
                Statement stmt = connectDB.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM inventory");
                double dough = 0;
                double Pepperoni = 0;
                double PizzaSauce = 0;
                double Cheese = 0;
                double GreenPepper = 0;
                double BlackOlive = 0;
                double PineApple = 0;
                double CanadianBacon = 0;
                double Sausage = 0;
                while (rs.next()) {
                    dough = rs.getDouble("dough");
                    Pepperoni = rs.getDouble("Pepperoni");
                    PizzaSauce = rs.getDouble("PizzaSauce");
                    Cheese = rs.getDouble("Cheese");
                    GreenPepper = rs.getDouble("GreenPepper");
                    BlackOlive = rs.getDouble("BlackOlive");
                    PineApple = rs.getDouble("PineApple");
                    CanadianBacon = rs.getDouble("CanadianBacon");
                    Sausage = rs.getDouble("Sausage");
                }
                DoughText.setText(""+dough+"");
                InventoryPeppText.setText(""+Pepperoni+"");
                SauceText.setText(""+PizzaSauce+"");
                InventoryCheeseText.setText(""+Cheese+"");
                GreenText.setText(""+GreenPepper+"");
                BlackText.setText(""+BlackOlive+"");
                PineText.setText(""+PineApple+"");
                CanadianText.setText(""+CanadianBacon+"");
                InventorySausageText.setText(""+Sausage+"");
            } catch (Exception e) {
                System.err.println("Got an exception!");
                // printStackTrace method
                // prints line numbers + call stack
                e.printStackTrace();
                // Prints what exception has been thrown
                System.out.println(e);
            }
    }
    @FXML
    void Tclock(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("TimeClock.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private TextArea PostingsText;
    @FXML
    public void PostingsClicked(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Postings.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    private TableView<?> PostingsTable;
    public void GenerateIndex(ActionEvent event) throws IOException {
        String Orders = "";
        try {
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();
            Statement stmt = connectDB.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM orders");
            String Hello = "";
            ObservableList<OrderObject> data = FXCollections.observableArrayList();

            int theOrderID = 0;
            String name = null;
            int pepperoni = 0;
            int sausage = 0;
            int work = 0;
            int hawian = 0;
            int cheese = 0;
            double total = 0;
            OrderObject OrderObject = null;
            while (rs.next()) {
                theOrderID = rs.getInt("Orderid");
                name = rs.getString("OrderName");
                pepperoni = rs.getInt("PepperoniQuantity");
                sausage = rs.getInt("SausageQuantity");
                work = rs.getInt("WorkQuantity");
                hawian = rs.getInt("HawianQuantity");
                cheese = rs.getInt("CheesePizza");
                total = rs.getDouble("Total");
                Hello += ("\nID: " + theOrderID + " |" + "Name: " + name + " |" + "Pepperoni: " + pepperoni + " |" + "Sausage: " + sausage + " |" + "Work: " + work + " |" + "Hawian: " + hawian + " |" + "Cheese: " + cheese + " |" + "Total: $" + total + "\n");
                OrderObject = new OrderObject(theOrderID, name, pepperoni, sausage, work, hawian, cheese, total);
                data.add(OrderObject);
            }
            TableView<OrderObject> tableView;
            /*tableView = (TableView<OrderObject>) Postings.lookup("#PostingsTable");

            TableColumn<OrderObject, Integer> theOrderIDcol = new TableColumn<>("Order ID");
            theOrderIDcol.setCellValueFactory(new PropertyValueFactory<>("" + theOrderID + ""));

            TableColumn<OrderObject, String> nameCol = new TableColumn<>("Age");
            nameCol.setCellValueFactory(new PropertyValueFactory<>("" + name + ""));

            TableColumn<OrderObject, Integer> pepperoniCol = new TableColumn<>("Pepperoni");
            pepperoniCol.setCellValueFactory(new PropertyValueFactory<>("" + pepperoni + ""));

            TableColumn<OrderObject, Integer> SausageCol = new TableColumn<>("Sausage");
            SausageCol.setCellValueFactory(new PropertyValueFactory<>("" + sausage + ""));

            TableColumn<OrderObject, Integer> WorkCol = new TableColumn<>("Work");
            WorkCol.setCellValueFactory(new PropertyValueFactory<>("" + work + ""));

            TableColumn<OrderObject, Integer> HawianCol = new TableColumn<>("Hawian");
            HawianCol.setCellValueFactory(new PropertyValueFactory<>("" + hawian + ""));

            TableColumn<OrderObject, Integer> CheeseCol = new TableColumn<>("Cheese");
            CheeseCol.setCellValueFactory(new PropertyValueFactory<>("" + cheese + ""));

            TableColumn<OrderObject, Double> TotalCol = new TableColumn<>("Total");
            TotalCol.setCellValueFactory(new PropertyValueFactory<>("" + total + ""));

            tableView.getColumns().addAll(theOrderIDcol, nameCol, pepperoniCol, SausageCol, WorkCol, HawianCol, CheeseCol, TotalCol);

            data.add(OrderObject);

            tableView.setItems(data);*/
            Orders = Hello;

        } catch (Exception e) {
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }
        System.out.println(Orders);
        PostingsText.setText("\n"+Orders);

    }

    @FXML
    void Stats(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Statistics.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void MOclick(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Manager.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    private void addEmployee(ActionEvent event) throws IOException {
        Parent root = (Parent)FXMLLoader.load(this.getClass().getResource("AddEmployee.fxml"));
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void addMenuItem(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(this.getClass().getResource("AddMenuItem.fxml"));
        Parent root = (Parent)loader.load();
        AddMenuItemController controller = (AddMenuItemController)loader.getController();
        List<MenuItem> menuItems = DataStore.getInstance().getMenuItems();
        controller.setMenuItems(menuItems);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void manageSchedules(ActionEvent event) throws IOException {
        Parent root = (Parent)FXMLLoader.load(this.getClass().getResource("ManageSchedules.fxml"));
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void viewReports(ActionEvent event) throws IOException {
        Parent root = (Parent)FXMLLoader.load(this.getClass().getResource("ViewReports.fxml"));
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    void BackToDirectory(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Directory.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

///////////////////////////////// The beginning of the code for the Product Order screen
    @FXML
    private TextField CheeseText;

    @FXML
    private TextField HawianText;

    @FXML
    private TextField NameText;

    @FXML
    private TextField PepperoniText;

    @FXML
    private TextField RecieptText;

    @FXML
    private TextField SausageText;

    @FXML
    private TextField TotalText;

    @FXML
    private TextField WorkText;

    public int cheeseQuant = 0;
    public int PepperoniQuant = 0;
    public int SausageQuant = 0;
    public int WorkQuant = 0;
    public int HawianQuant = 0;
    public int Orderid = 1;


    public double Totalint = 0.00;
    DecimalFormat df = new DecimalFormat("#.00");
    @FXML
    void Cheese(ActionEvent event) {
        cheeseQuant = cheeseQuant + 1;
        CheeseText.setText(""+ cheeseQuant +"");
        Totalint = Totalint + 12.00;
        RecieptText.setText("" + cheeseQuant +" [Cheese Pizza] $12.00");
        TotalText.setText("$" + df.format(Totalint) + "");
    }

    @FXML
    void Hawian(ActionEvent event) {
        HawianQuant = HawianQuant + 1;
        HawianText.setText(""+ HawianQuant +"");
        Totalint = Totalint + 13.98;
        RecieptText.setText("" + HawianQuant +" [Hawian Pizza] $13.98");
        TotalText.setText("$" + df.format(Totalint) + "");
    }

    @FXML
    void OrderProducts(ActionEvent event) throws SQLException {
        Ordertaker();

    }
    public void Ordertaker() throws SQLException {
        String Name = NameText.getText();
        Orderid = Orderid + 1;
        double newdough = PepperoniQuant*.2 + SausageQuant*.2 + WorkQuant*.2 + HawianQuant*.2 + cheeseQuant*.2;
        double newPepperoni = PepperoniQuant*.5 + WorkQuant*.2;
        double newPizzaSauce = PepperoniQuant*.1 + SausageQuant*.1 + WorkQuant*.1 + HawianQuant*.1 + cheeseQuant*.1;
        double newCheese = PepperoniQuant*.2 + SausageQuant*.2 + WorkQuant*.2 + HawianQuant*.2 + cheeseQuant*.2;
        double newGreenPepper = WorkQuant*.1;
        double newBlackOlive = WorkQuant*.25;
        double newPineApple = HawianQuant*.1;
        double newCanadianBacon = WorkQuant*.1 + HawianQuant*.1;
        double newSausage = SausageQuant*.1 + WorkQuant*.1;
        try{
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();
            String storeOrder = "INSERT INTO orders (Orderid, OrderName, PepperoniQuantity, SausageQuantity, WorkQuantity, HawianQuantity, CheesePizza, Total) VALUES (?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement preparedStmt = connectDB.prepareStatement(storeOrder);
            preparedStmt.setInt (1, Orderid);
            preparedStmt.setString (2, Name);
            preparedStmt.setInt   (3, PepperoniQuant);
            preparedStmt.setInt(4, SausageQuant);
            preparedStmt.setInt    (5, WorkQuant);
            preparedStmt.setInt    (6, HawianQuant);
            preparedStmt.setInt    (7, cheeseQuant);
            preparedStmt.setDouble   (8, Totalint);
            preparedStmt.execute();
            Statement stmt = connectDB.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM inventory");
            double dough = 0;
            double Pepperoni = 0;
            double PizzaSauce = 0;
            double Cheese = 0;
            double GreenPepper = 0;
            double BlackOlive = 0;
            double PineApple = 0;
            double CanadianBacon = 0;
            double Sausage = 0;
            while (rs.next()) {
                dough = rs.getDouble("dough");
                Pepperoni = rs.getDouble("Pepperoni");
                PizzaSauce = rs.getDouble("PizzaSauce");
                Cheese = rs.getDouble("Cheese");
                GreenPepper = rs.getDouble("GreenPepper");
                BlackOlive = rs.getDouble("BlackOlive");
                PineApple = rs.getDouble("PineApple");
                CanadianBacon = rs.getDouble("CanadianBacon");
                Sausage = rs.getDouble("Sausage");
            }
            double finaldough = dough - newdough;
            double finalPepperoni = Pepperoni - newPepperoni;
            double finalPizzaSauce = PizzaSauce - newPizzaSauce;
            double finalCheese = Cheese - newCheese;
            double finalGreenPepper = GreenPepper - newGreenPepper;
            double finalBlackOlive = BlackOlive - newBlackOlive;
            double finalPineApple = PineApple - newPineApple;
            double finalCanadianBacon = CanadianBacon - newCanadianBacon;
            double finalSausage = Sausage - newSausage;
            String truncate = "TRUNCATE TABLE inventory;";
            PreparedStatement truncateStmt = connectDB.prepareStatement(truncate);
            truncateStmt.execute();
            String updateinventory = "INSERT INTO inventory (InventoryID, dough, Pepperoni, PizzaSauce, Cheese, GreenPepper, BlackOlive, PineApple, CanadianBacon, Sausage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement OrderInventoryStmt = connectDB.prepareStatement(updateinventory);
            OrderInventoryStmt.setInt(1, 1);
            OrderInventoryStmt.setDouble(2, finaldough);
            OrderInventoryStmt.setDouble(3, finalPepperoni);
            OrderInventoryStmt.setDouble(4, finalPizzaSauce);
            OrderInventoryStmt.setDouble(5, finalCheese);
            OrderInventoryStmt.setDouble(6, finalGreenPepper);
            OrderInventoryStmt.setDouble(7, finalBlackOlive);
            OrderInventoryStmt.setDouble(8, finalPineApple);
            OrderInventoryStmt.setDouble(9, finalCanadianBacon);
            OrderInventoryStmt.setDouble(10, finalSausage);

            OrderInventoryStmt.execute();
            connectDB.close();
        }
        catch(Exception e){
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }

    }
    @FXML
    void Pepperoni(ActionEvent event) {
        PepperoniQuant = PepperoniQuant + 1;
        PepperoniText.setText(""+ PepperoniQuant +"");
        Totalint = Totalint + 12.98;
        RecieptText.setText("" + PepperoniQuant +" [Pepperoni Pizza] $12.98");
        TotalText.setText("$" + df.format(Totalint) + "");
    }

    @FXML
    void RemoveCheese(ActionEvent event) {
        cheeseQuant = cheeseQuant - 1;
        CheeseText.setText(""+ cheeseQuant +"");
        Totalint = Totalint - 12.00;
        RecieptText.setText("" + cheeseQuant +" [Cheese Pizza] $12.00");
        TotalText.setText("$" + df.format(Totalint) + "");
    }

    @FXML
    void RemoveHawian(ActionEvent event) {
        HawianQuant = HawianQuant - 1;
        HawianText.setText(""+ HawianQuant +"");
        Totalint = Totalint - 13.98;
        RecieptText.setText("" + HawianQuant +" [Hawian Pizza] $13.98");
        TotalText.setText("$" + df.format(Totalint) + "");
    }

    @FXML
    void RemovePepperoni(ActionEvent event) {
        PepperoniQuant = PepperoniQuant - 1;
        PepperoniText.setText(""+ PepperoniQuant +"");
        Totalint = Totalint - 12.98;
        RecieptText.setText("" + PepperoniQuant +" [Pepperoni Pizza] $12.98");
        TotalText.setText("$" + df.format(Totalint) + "");
    }

    @FXML
    void RemoveSausage(ActionEvent event) {
        SausageQuant = SausageQuant - 1;
        SausageText.setText(""+ SausageQuant +"");
        Totalint = Totalint - 15.98;
        RecieptText.setText("" + SausageQuant +" [Sausage Pizza] $15.98");
        TotalText.setText("$" + df.format(Totalint) + "");
    }

    @FXML
    void RemoveWork(ActionEvent event) {
        WorkQuant = WorkQuant - 1;
        WorkText.setText(""+ WorkQuant +"");
        Totalint = Totalint - 19.98;
        RecieptText.setText("" + WorkQuant +" [Pepperoni Pizza] $19.98");
        TotalText.setText("$" + df.format(Totalint) + "");
    }

    @FXML
    void Sausage(ActionEvent event) {
        SausageQuant = SausageQuant + 1;
        SausageText.setText(""+ SausageQuant +"");
        Totalint = Totalint + 15.98;
        RecieptText.setText("" + SausageQuant +" [Sausage Pizza] $15.98");
        TotalText.setText("$" + df.format(Totalint) + "");
    }

    @FXML
    void Work(ActionEvent event) {
        WorkQuant = WorkQuant + 1;
        WorkText.setText(""+ WorkQuant +"");
        Totalint = Totalint + 19.98;
        RecieptText.setText("" + WorkQuant +" [Work Pizza] $19.98");
        TotalText.setText("$" + df.format(Totalint) + "");
    }

///////////////////////////////////////////////////////////////////////////This is the beginning of the code for the Inventory
    @FXML
    private TextField BlackText;

    @FXML
    private TextField CanadianText;

    @FXML
    private TextField DoughText;

    @FXML
    private TextField GreenText;

    @FXML
    private TextField InventoryCheeseText;

    @FXML
    private TextField InventoryPeppText;

    @FXML
    private TextField InventorySausageText;

    @FXML
    private TextField PineText;

    @FXML
    private TextField SauceText;

    @FXML
    private TextField OrderPine;
    @FXML
    private TextField OrderSauce;
    @FXML
    private TextField OrderSausage;
    @FXML
    private TextField OrderPepp;
    @FXML
    private TextField OrderGreen;
    @FXML
    private TextField OrderDough;
    @FXML
    private TextField OCanadian;
    @FXML
    private TextField OrderCheese;
    @FXML
    private TextField OrderBlackOlives;



    @FXML
    void InvRemoveCheese(ActionEvent event) {
        double cheese = Double.parseDouble(InventoryCheeseText.getText()) - 1;
        InventoryCheeseText.setText("" +cheese+ "");
        double dough = Double.parseDouble(DoughText.getText());
        double Sausage = Double.parseDouble(InventorySausageText.getText());
        double Pepperoni = Double.parseDouble(InventoryPeppText.getText());
        double GreenPeppers = Double.parseDouble(GreenText.getText());
        double BlackOlives = Double.parseDouble(BlackText.getText());
        double CanadianBacon = Double.parseDouble(CanadianText.getText());
        double Pineapple = Double.parseDouble(PineText.getText());
        double PizzaSauce = Double.parseDouble(SauceText.getText());
        double Cheese = Double.parseDouble(InventoryCheeseText.getText());
        try{
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();
            String truncate = "TRUNCATE TABLE inventory;";
            PreparedStatement truncateStmt = connectDB.prepareStatement(truncate);
            truncateStmt.execute();
            String updateinventory = "INSERT INTO inventory (InventoryID, dough, Pepperoni, PizzaSauce, Cheese, GreenPepper, BlackOlive, PineApple, CanadianBacon, Sausage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement preparedStmt = connectDB.prepareStatement(updateinventory);
            preparedStmt.setInt(1, 1);
            preparedStmt.setDouble(2, dough);
            preparedStmt.setDouble(3, Pepperoni);
            preparedStmt.setDouble(4, PizzaSauce);
            preparedStmt.setDouble(5, Cheese);
            preparedStmt.setDouble(6, GreenPeppers);
            preparedStmt.setDouble(7, BlackOlives);
            preparedStmt.setDouble(8, Pineapple);
            preparedStmt.setDouble(9, CanadianBacon);
            preparedStmt.setDouble(10, Sausage);

            preparedStmt.execute();
            connectDB.close();
        }
        catch(Exception e){
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }
    }

    @FXML
    void InvRemovePepperoni(ActionEvent event) {
        double pepperoni = Double.parseDouble(InventoryPeppText.getText()) - 1;
        InventoryPeppText.setText("" +pepperoni+ "");
        double dough = Double.parseDouble(DoughText.getText());
        double Sausage = Double.parseDouble(InventorySausageText.getText());
        double Pepperoni = Double.parseDouble(InventoryPeppText.getText());
        double GreenPeppers = Double.parseDouble(GreenText.getText());
        double BlackOlives = Double.parseDouble(BlackText.getText());
        double CanadianBacon = Double.parseDouble(CanadianText.getText());
        double Pineapple = Double.parseDouble(PineText.getText());
        double PizzaSauce = Double.parseDouble(SauceText.getText());
        double Cheese = Double.parseDouble(InventoryCheeseText.getText());
        try{
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();
            String truncate = "TRUNCATE TABLE inventory;";
            PreparedStatement truncateStmt = connectDB.prepareStatement(truncate);
            truncateStmt.execute();
            String updateinventory = "INSERT INTO inventory (InventoryID, dough, Pepperoni, PizzaSauce, Cheese, GreenPepper, BlackOlive, PineApple, CanadianBacon, Sausage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement preparedStmt = connectDB.prepareStatement(updateinventory);
            preparedStmt.setInt(1, 1);
            preparedStmt.setDouble(2, dough);
            preparedStmt.setDouble(3, Pepperoni);
            preparedStmt.setDouble(4, PizzaSauce);
            preparedStmt.setDouble(5, Cheese);
            preparedStmt.setDouble(6, GreenPeppers);
            preparedStmt.setDouble(7, BlackOlives);
            preparedStmt.setDouble(8, Pineapple);
            preparedStmt.setDouble(9, CanadianBacon);
            preparedStmt.setDouble(10, Sausage);

            preparedStmt.execute();
            connectDB.close();
        }
        catch(Exception e){
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }
    }

    @FXML
    void InvRemoveSausage(ActionEvent event) {
        double sausage = Double.parseDouble(InventorySausageText.getText()) - 1;
        InventorySausageText.setText("" +sausage+ "");
        double dough = Double.parseDouble(DoughText.getText());
        double Sausage = Double.parseDouble(InventorySausageText.getText());
        double Pepperoni = Double.parseDouble(InventoryPeppText.getText());
        double GreenPeppers = Double.parseDouble(GreenText.getText());
        double BlackOlives = Double.parseDouble(BlackText.getText());
        double CanadianBacon = Double.parseDouble(CanadianText.getText());
        double Pineapple = Double.parseDouble(PineText.getText());
        double PizzaSauce = Double.parseDouble(SauceText.getText());
        double Cheese = Double.parseDouble(InventoryCheeseText.getText());
        try{
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();
            String truncate = "TRUNCATE TABLE inventory;";
            PreparedStatement truncateStmt = connectDB.prepareStatement(truncate);
            truncateStmt.execute();
            String updateinventory = "INSERT INTO inventory (InventoryID, dough, Pepperoni, PizzaSauce, Cheese, GreenPepper, BlackOlive, PineApple, CanadianBacon, Sausage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement preparedStmt = connectDB.prepareStatement(updateinventory);
            preparedStmt.setInt(1, 1);
            preparedStmt.setDouble(2, dough);
            preparedStmt.setDouble(3, Pepperoni);
            preparedStmt.setDouble(4, PizzaSauce);
            preparedStmt.setDouble(5, Cheese);
            preparedStmt.setDouble(6, GreenPeppers);
            preparedStmt.setDouble(7, BlackOlives);
            preparedStmt.setDouble(8, Pineapple);
            preparedStmt.setDouble(9, CanadianBacon);
            preparedStmt.setDouble(10, Sausage);

            preparedStmt.execute();
            connectDB.close();
        }
        catch(Exception e){
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }
    }

    @FXML
    void OrderBlack(ActionEvent event) {
        double OBlack = Double.parseDouble(OrderBlackOlives.getText());
        double CurrBlack = Double.parseDouble(BlackText.getText()) + OBlack;
        BlackText.setText(""+CurrBlack+"");
        double dough = Double.parseDouble(DoughText.getText());
        double Sausage = Double.parseDouble(InventorySausageText.getText());
        double Pepperoni = Double.parseDouble(InventoryPeppText.getText());
        double GreenPeppers = Double.parseDouble(GreenText.getText());
        double BlackOlives = Double.parseDouble(BlackText.getText());
        double CanadianBacon = Double.parseDouble(CanadianText.getText());
        double Pineapple = Double.parseDouble(PineText.getText());
        double PizzaSauce = Double.parseDouble(SauceText.getText());
        double Cheese = Double.parseDouble(InventoryCheeseText.getText());
        try{
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();
            String truncate = "TRUNCATE TABLE inventory;";
            PreparedStatement truncateStmt = connectDB.prepareStatement(truncate);
            truncateStmt.execute();
            String updateinventory = "INSERT INTO inventory (InventoryID, dough, Pepperoni, PizzaSauce, Cheese, GreenPepper, BlackOlive, PineApple, CanadianBacon, Sausage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement preparedStmt = connectDB.prepareStatement(updateinventory);
            preparedStmt.setInt(1, 1);
            preparedStmt.setDouble(2, dough);
            preparedStmt.setDouble(3, Pepperoni);
            preparedStmt.setDouble(4, PizzaSauce);
            preparedStmt.setDouble(5, Cheese);
            preparedStmt.setDouble(6, GreenPeppers);
            preparedStmt.setDouble(7, BlackOlives);
            preparedStmt.setDouble(8, Pineapple);
            preparedStmt.setDouble(9, CanadianBacon);
            preparedStmt.setDouble(10, Sausage);

            preparedStmt.execute();
            connectDB.close();
        }
        catch(Exception e){
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }
    }

    @FXML
    void OrderCanadian(ActionEvent event) {
        double OCanada = Double.parseDouble(OCanadian.getText());
        double CurrCanada = Double.parseDouble(CanadianText.getText()) + OCanada;
        CanadianText.setText(""+CurrCanada+"");
        double dough = Double.parseDouble(DoughText.getText());
        double Sausage = Double.parseDouble(InventorySausageText.getText());
        double Pepperoni = Double.parseDouble(InventoryPeppText.getText());
        double GreenPeppers = Double.parseDouble(GreenText.getText());
        double BlackOlives = Double.parseDouble(BlackText.getText());
        double CanadianBacon = Double.parseDouble(CanadianText.getText());
        double Pineapple = Double.parseDouble(PineText.getText());
        double PizzaSauce = Double.parseDouble(SauceText.getText());
        double Cheese = Double.parseDouble(InventoryCheeseText.getText());
        try{
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();
            String truncate = "TRUNCATE TABLE inventory;";
            PreparedStatement truncateStmt = connectDB.prepareStatement(truncate);
            truncateStmt.execute();
            String updateinventory = "INSERT INTO inventory (InventoryID, dough, Pepperoni, PizzaSauce, Cheese, GreenPepper, BlackOlive, PineApple, CanadianBacon, Sausage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement preparedStmt = connectDB.prepareStatement(updateinventory);
            preparedStmt.setInt(1, 1);
            preparedStmt.setDouble(2, dough);
            preparedStmt.setDouble(3, Pepperoni);
            preparedStmt.setDouble(4, PizzaSauce);
            preparedStmt.setDouble(5, Cheese);
            preparedStmt.setDouble(6, GreenPeppers);
            preparedStmt.setDouble(7, BlackOlives);
            preparedStmt.setDouble(8, Pineapple);
            preparedStmt.setDouble(9, CanadianBacon);
            preparedStmt.setDouble(10, Sausage);

            preparedStmt.execute();
            connectDB.close();
        }
        catch(Exception e){
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }
    }

    @FXML
    void OrderCheese(ActionEvent event) {
        double OCheese = Double.parseDouble(OrderCheese.getText());
        double CurrCheese = Double.parseDouble(InventoryCheeseText.getText()) + OCheese;
        InventoryCheeseText.setText(""+CurrCheese+"");
        double dough = Double.parseDouble(DoughText.getText());
        double Sausage = Double.parseDouble(InventorySausageText.getText());
        double Pepperoni = Double.parseDouble(InventoryPeppText.getText());
        double GreenPeppers = Double.parseDouble(GreenText.getText());
        double BlackOlives = Double.parseDouble(BlackText.getText());
        double CanadianBacon = Double.parseDouble(CanadianText.getText());
        double Pineapple = Double.parseDouble(PineText.getText());
        double PizzaSauce = Double.parseDouble(SauceText.getText());
        double Cheese = Double.parseDouble(InventoryCheeseText.getText());
        try{
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();
            String truncate = "TRUNCATE TABLE inventory;";
            PreparedStatement truncateStmt = connectDB.prepareStatement(truncate);
            truncateStmt.execute();
            String updateinventory = "INSERT INTO inventory (InventoryID, dough, Pepperoni, PizzaSauce, Cheese, GreenPepper, BlackOlive, PineApple, CanadianBacon, Sausage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement preparedStmt = connectDB.prepareStatement(updateinventory);
            preparedStmt.setInt(1, 1);
            preparedStmt.setDouble(2, dough);
            preparedStmt.setDouble(3, Pepperoni);
            preparedStmt.setDouble(4, PizzaSauce);
            preparedStmt.setDouble(5, Cheese);
            preparedStmt.setDouble(6, GreenPeppers);
            preparedStmt.setDouble(7, BlackOlives);
            preparedStmt.setDouble(8, Pineapple);
            preparedStmt.setDouble(9, CanadianBacon);
            preparedStmt.setDouble(10, Sausage);

            preparedStmt.execute();
            connectDB.close();
        }
        catch(Exception e){
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }
    }

    @FXML
    void OrderDough(ActionEvent event) {
        double ODough = Double.parseDouble(OrderDough.getText());
        double CurrDough = Double.parseDouble(DoughText.getText()) + ODough;
        DoughText.setText(""+CurrDough+"");
        double dough = Double.parseDouble(DoughText.getText());
        double Sausage = Double.parseDouble(InventorySausageText.getText());
        double Pepperoni = Double.parseDouble(InventoryPeppText.getText());
        double GreenPeppers = Double.parseDouble(GreenText.getText());
        double BlackOlives = Double.parseDouble(BlackText.getText());
        double CanadianBacon = Double.parseDouble(CanadianText.getText());
        double Pineapple = Double.parseDouble(PineText.getText());
        double PizzaSauce = Double.parseDouble(SauceText.getText());
        double Cheese = Double.parseDouble(InventoryCheeseText.getText());
        try{
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();
            String truncate = "TRUNCATE TABLE inventory;";
            PreparedStatement truncateStmt = connectDB.prepareStatement(truncate);
            truncateStmt.execute();
            String updateinventory = "INSERT INTO inventory (InventoryID, dough, Pepperoni, PizzaSauce, Cheese, GreenPepper, BlackOlive, PineApple, CanadianBacon, Sausage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement preparedStmt = connectDB.prepareStatement(updateinventory);
            preparedStmt.setInt(1, 1);
            preparedStmt.setDouble(2, dough);
            preparedStmt.setDouble(3, Pepperoni);
            preparedStmt.setDouble(4, PizzaSauce);
            preparedStmt.setDouble(5, Cheese);
            preparedStmt.setDouble(6, GreenPeppers);
            preparedStmt.setDouble(7, BlackOlives);
            preparedStmt.setDouble(8, Pineapple);
            preparedStmt.setDouble(9, CanadianBacon);
            preparedStmt.setDouble(10, Sausage);

            preparedStmt.execute();
            connectDB.close();
        }
        catch(Exception e){
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }



    }

    @FXML
    void OrderGreen(ActionEvent event) {
        double OGreen = Double.parseDouble(OrderGreen.getText());
        double CurrGreen = Double.parseDouble(GreenText.getText()) + OGreen;
        GreenText.setText(""+CurrGreen+"");
        double dough = Double.parseDouble(DoughText.getText());
        double Sausage = Double.parseDouble(InventorySausageText.getText());
        double Pepperoni = Double.parseDouble(InventoryPeppText.getText());
        double GreenPeppers = Double.parseDouble(GreenText.getText());
        double BlackOlives = Double.parseDouble(BlackText.getText());
        double CanadianBacon = Double.parseDouble(CanadianText.getText());
        double Pineapple = Double.parseDouble(PineText.getText());
        double PizzaSauce = Double.parseDouble(SauceText.getText());
        double Cheese = Double.parseDouble(InventoryCheeseText.getText());
        try{
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();
            String truncate = "TRUNCATE TABLE inventory;";
            PreparedStatement truncateStmt = connectDB.prepareStatement(truncate);
            truncateStmt.execute();
            String updateinventory = "INSERT INTO inventory (InventoryID, dough, Pepperoni, PizzaSauce, Cheese, GreenPepper, BlackOlive, PineApple, CanadianBacon, Sausage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement preparedStmt = connectDB.prepareStatement(updateinventory);
            preparedStmt.setInt(1, 1);
            preparedStmt.setDouble(2, dough);
            preparedStmt.setDouble(3, Pepperoni);
            preparedStmt.setDouble(4, PizzaSauce);
            preparedStmt.setDouble(5, Cheese);
            preparedStmt.setDouble(6, GreenPeppers);
            preparedStmt.setDouble(7, BlackOlives);
            preparedStmt.setDouble(8, Pineapple);
            preparedStmt.setDouble(9, CanadianBacon);
            preparedStmt.setDouble(10, Sausage);

            preparedStmt.execute();
            connectDB.close();
        }
        catch(Exception e){
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }
    }

    @FXML
    void OrderPepperoni(ActionEvent event) {
        double OPepp = Double.parseDouble(OrderPepp.getText());
        double CurrPepp = Double.parseDouble(InventoryPeppText.getText()) + OPepp;
        InventoryPeppText.setText(""+CurrPepp+"");
        double dough = Double.parseDouble(DoughText.getText());
        double Sausage = Double.parseDouble(InventorySausageText.getText());
        double Pepperoni = Double.parseDouble(InventoryPeppText.getText());
        double GreenPeppers = Double.parseDouble(GreenText.getText());
        double BlackOlives = Double.parseDouble(BlackText.getText());
        double CanadianBacon = Double.parseDouble(CanadianText.getText());
        double Pineapple = Double.parseDouble(PineText.getText());
        double PizzaSauce = Double.parseDouble(SauceText.getText());
        double Cheese = Double.parseDouble(InventoryCheeseText.getText());
        try{
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();
            String truncate = "TRUNCATE TABLE inventory;";
            PreparedStatement truncateStmt = connectDB.prepareStatement(truncate);
            truncateStmt.execute();
            String updateinventory = "INSERT INTO inventory (InventoryID, dough, Pepperoni, PizzaSauce, Cheese, GreenPepper, BlackOlive, PineApple, CanadianBacon, Sausage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement preparedStmt = connectDB.prepareStatement(updateinventory);
            preparedStmt.setInt(1, 1);
            preparedStmt.setDouble(2, dough);
            preparedStmt.setDouble(3, Pepperoni);
            preparedStmt.setDouble(4, PizzaSauce);
            preparedStmt.setDouble(5, Cheese);
            preparedStmt.setDouble(6, GreenPeppers);
            preparedStmt.setDouble(7, BlackOlives);
            preparedStmt.setDouble(8, Pineapple);
            preparedStmt.setDouble(9, CanadianBacon);
            preparedStmt.setDouble(10, Sausage);

            preparedStmt.execute();
            connectDB.close();
        }
        catch(Exception e){
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }
    }

    @FXML
    void OrderPine(ActionEvent event) {
        double OPine = Double.parseDouble(OrderPine.getText());
        double CurrPine = Double.parseDouble(PineText.getText()) + OPine;
        PineText.setText(""+CurrPine+"");
        double dough = Double.parseDouble(DoughText.getText());
        double Sausage = Double.parseDouble(InventorySausageText.getText());
        double Pepperoni = Double.parseDouble(InventoryPeppText.getText());
        double GreenPeppers = Double.parseDouble(GreenText.getText());
        double BlackOlives = Double.parseDouble(BlackText.getText());
        double CanadianBacon = Double.parseDouble(CanadianText.getText());
        double Pineapple = Double.parseDouble(PineText.getText());
        double PizzaSauce = Double.parseDouble(SauceText.getText());
        double Cheese = Double.parseDouble(InventoryCheeseText.getText());
        try{
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();
            String truncate = "TRUNCATE TABLE inventory;";
            PreparedStatement truncateStmt = connectDB.prepareStatement(truncate);
            truncateStmt.execute();
            String updateinventory = "INSERT INTO inventory (InventoryID, dough, Pepperoni, PizzaSauce, Cheese, GreenPepper, BlackOlive, PineApple, CanadianBacon, Sausage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement preparedStmt = connectDB.prepareStatement(updateinventory);
            preparedStmt.setInt(1, 1);
            preparedStmt.setDouble(2, dough);
            preparedStmt.setDouble(3, Pepperoni);
            preparedStmt.setDouble(4, PizzaSauce);
            preparedStmt.setDouble(5, Cheese);
            preparedStmt.setDouble(6, GreenPeppers);
            preparedStmt.setDouble(7, BlackOlives);
            preparedStmt.setDouble(8, Pineapple);
            preparedStmt.setDouble(9, CanadianBacon);
            preparedStmt.setDouble(10, Sausage);

            preparedStmt.execute();
            connectDB.close();
        }
        catch(Exception e){
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }
    }

    @FXML
    void OrderSauce(ActionEvent event) {
        double OSauce = Double.parseDouble(OrderSauce.getText());
        double CurrSauce = Double.parseDouble(SauceText.getText()) + OSauce;
        SauceText.setText(""+CurrSauce+"");
        double dough = Double.parseDouble(DoughText.getText());
        double Sausage = Double.parseDouble(InventorySausageText.getText());
        double Pepperoni = Double.parseDouble(InventoryPeppText.getText());
        double GreenPeppers = Double.parseDouble(GreenText.getText());
        double BlackOlives = Double.parseDouble(BlackText.getText());
        double CanadianBacon = Double.parseDouble(CanadianText.getText());
        double Pineapple = Double.parseDouble(PineText.getText());
        double PizzaSauce = Double.parseDouble(SauceText.getText());
        double Cheese = Double.parseDouble(InventoryCheeseText.getText());
        try{
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();
            String truncate = "TRUNCATE TABLE inventory;";
            PreparedStatement truncateStmt = connectDB.prepareStatement(truncate);
            truncateStmt.execute();
            String updateinventory = "INSERT INTO inventory (InventoryID, dough, Pepperoni, PizzaSauce, Cheese, GreenPepper, BlackOlive, PineApple, CanadianBacon, Sausage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement preparedStmt = connectDB.prepareStatement(updateinventory);
            preparedStmt.setInt(1, 1);
            preparedStmt.setDouble(2, dough);
            preparedStmt.setDouble(3, Pepperoni);
            preparedStmt.setDouble(4, PizzaSauce);
            preparedStmt.setDouble(5, Cheese);
            preparedStmt.setDouble(6, GreenPeppers);
            preparedStmt.setDouble(7, BlackOlives);
            preparedStmt.setDouble(8, Pineapple);
            preparedStmt.setDouble(9, CanadianBacon);
            preparedStmt.setDouble(10, Sausage);

            preparedStmt.execute();
            connectDB.close();
        }
        catch(Exception e){
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }
    }

    @FXML
    void OrderSausage(ActionEvent event) {
        double OSausage = Double.parseDouble(OrderSausage.getText());
        double CurrSausage = Double.parseDouble(InventorySausageText.getText()) + OSausage;
        InventorySausageText.setText(""+CurrSausage+"");
        double dough = Double.parseDouble(DoughText.getText());
        double Sausage = Double.parseDouble(InventorySausageText.getText());
        double Pepperoni = Double.parseDouble(InventoryPeppText.getText());
        double GreenPeppers = Double.parseDouble(GreenText.getText());
        double BlackOlives = Double.parseDouble(BlackText.getText());
        double CanadianBacon = Double.parseDouble(CanadianText.getText());
        double Pineapple = Double.parseDouble(PineText.getText());
        double PizzaSauce = Double.parseDouble(SauceText.getText());
        double Cheese = Double.parseDouble(InventoryCheeseText.getText());
        try{
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();
            String truncate = "TRUNCATE TABLE inventory;";
            PreparedStatement truncateStmt = connectDB.prepareStatement(truncate);
            truncateStmt.execute();
            String updateinventory = "INSERT INTO inventory (InventoryID, dough, Pepperoni, PizzaSauce, Cheese, GreenPepper, BlackOlive, PineApple, CanadianBacon, Sausage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement preparedStmt = connectDB.prepareStatement(updateinventory);
            preparedStmt.setInt(1, 1);
            preparedStmt.setDouble(2, dough);
            preparedStmt.setDouble(3, Pepperoni);
            preparedStmt.setDouble(4, PizzaSauce);
            preparedStmt.setDouble(5, Cheese);
            preparedStmt.setDouble(6, GreenPeppers);
            preparedStmt.setDouble(7, BlackOlives);
            preparedStmt.setDouble(8, Pineapple);
            preparedStmt.setDouble(9, CanadianBacon);
            preparedStmt.setDouble(10, Sausage);

            preparedStmt.execute();
            connectDB.close();
        }
        catch(Exception e){
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }
    }

    @FXML
    void RemoveBlack(ActionEvent event) {
        double BlackOlive = Double.parseDouble(BlackText.getText()) - 1;
        BlackText.setText("" +BlackOlive+ "");
        double dough = Double.parseDouble(DoughText.getText());
        double Sausage = Double.parseDouble(InventorySausageText.getText());
        double Pepperoni = Double.parseDouble(InventoryPeppText.getText());
        double GreenPeppers = Double.parseDouble(GreenText.getText());
        double BlackOlives = Double.parseDouble(BlackText.getText());
        double CanadianBacon = Double.parseDouble(CanadianText.getText());
        double Pineapple = Double.parseDouble(PineText.getText());
        double PizzaSauce = Double.parseDouble(SauceText.getText());
        double Cheese = Double.parseDouble(InventoryCheeseText.getText());
        try{
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();
            String truncate = "TRUNCATE TABLE inventory;";
            PreparedStatement truncateStmt = connectDB.prepareStatement(truncate);
            truncateStmt.execute();
            String updateinventory = "INSERT INTO inventory (InventoryID, dough, Pepperoni, PizzaSauce, Cheese, GreenPepper, BlackOlive, PineApple, CanadianBacon, Sausage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement preparedStmt = connectDB.prepareStatement(updateinventory);
            preparedStmt.setInt(1, 1);
            preparedStmt.setDouble(2, dough);
            preparedStmt.setDouble(3, Pepperoni);
            preparedStmt.setDouble(4, PizzaSauce);
            preparedStmt.setDouble(5, Cheese);
            preparedStmt.setDouble(6, GreenPeppers);
            preparedStmt.setDouble(7, BlackOlives);
            preparedStmt.setDouble(8, Pineapple);
            preparedStmt.setDouble(9, CanadianBacon);
            preparedStmt.setDouble(10, Sausage);

            preparedStmt.execute();
            connectDB.close();
        }
        catch(Exception e){
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }
    }

    @FXML
    void RemoveCanadian(ActionEvent event) {
        double canada = Double.parseDouble(CanadianText.getText()) - 1;
        CanadianText.setText("" +canada+ "");
        double dough = Double.parseDouble(DoughText.getText());
        double Sausage = Double.parseDouble(InventorySausageText.getText());
        double Pepperoni = Double.parseDouble(InventoryPeppText.getText());
        double GreenPeppers = Double.parseDouble(GreenText.getText());
        double BlackOlives = Double.parseDouble(BlackText.getText());
        double CanadianBacon = Double.parseDouble(CanadianText.getText());
        double Pineapple = Double.parseDouble(PineText.getText());
        double PizzaSauce = Double.parseDouble(SauceText.getText());
        double Cheese = Double.parseDouble(InventoryCheeseText.getText());
        try{
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();
            String truncate = "TRUNCATE TABLE inventory;";
            PreparedStatement truncateStmt = connectDB.prepareStatement(truncate);
            truncateStmt.execute();
            String updateinventory = "INSERT INTO inventory (InventoryID, dough, Pepperoni, PizzaSauce, Cheese, GreenPepper, BlackOlive, PineApple, CanadianBacon, Sausage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement preparedStmt = connectDB.prepareStatement(updateinventory);
            preparedStmt.setInt(1, 1);
            preparedStmt.setDouble(2, dough);
            preparedStmt.setDouble(3, Pepperoni);
            preparedStmt.setDouble(4, PizzaSauce);
            preparedStmt.setDouble(5, Cheese);
            preparedStmt.setDouble(6, GreenPeppers);
            preparedStmt.setDouble(7, BlackOlives);
            preparedStmt.setDouble(8, Pineapple);
            preparedStmt.setDouble(9, CanadianBacon);
            preparedStmt.setDouble(10, Sausage);

            preparedStmt.execute();
            connectDB.close();
        }
        catch(Exception e){
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }
    }

    @FXML
    void RemoveDough(ActionEvent event) {
        double Dough = Double.parseDouble(DoughText.getText()) - 1;
        DoughText.setText("" +Dough+ "");
        double dough = Double.parseDouble(DoughText.getText());
        double Sausage = Double.parseDouble(InventorySausageText.getText());
        double Pepperoni = Double.parseDouble(InventoryPeppText.getText());
        double GreenPeppers = Double.parseDouble(GreenText.getText());
        double BlackOlives = Double.parseDouble(BlackText.getText());
        double CanadianBacon = Double.parseDouble(CanadianText.getText());
        double Pineapple = Double.parseDouble(PineText.getText());
        double PizzaSauce = Double.parseDouble(SauceText.getText());
        double Cheese = Double.parseDouble(InventoryCheeseText.getText());
        try{
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();
            String truncate = "TRUNCATE TABLE inventory;";
            PreparedStatement truncateStmt = connectDB.prepareStatement(truncate);
            truncateStmt.execute();
            String updateinventory = "INSERT INTO inventory (InventoryID, dough, Pepperoni, PizzaSauce, Cheese, GreenPepper, BlackOlive, PineApple, CanadianBacon, Sausage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement preparedStmt = connectDB.prepareStatement(updateinventory);
            preparedStmt.setInt(1, 1);
            preparedStmt.setDouble(2, dough);
            preparedStmt.setDouble(3, Pepperoni);
            preparedStmt.setDouble(4, PizzaSauce);
            preparedStmt.setDouble(5, Cheese);
            preparedStmt.setDouble(6, GreenPeppers);
            preparedStmt.setDouble(7, BlackOlives);
            preparedStmt.setDouble(8, Pineapple);
            preparedStmt.setDouble(9, CanadianBacon);
            preparedStmt.setDouble(10, Sausage);

            preparedStmt.execute();
            connectDB.close();
        }
        catch(Exception e){
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }
    }

    @FXML
    void RemoveGreen(ActionEvent event) {
        double Green = Double.parseDouble(GreenText.getText()) - 1;
        GreenText.setText("" +Green+ "");
        double dough = Double.parseDouble(DoughText.getText());
        double Sausage = Double.parseDouble(InventorySausageText.getText());
        double Pepperoni = Double.parseDouble(InventoryPeppText.getText());
        double GreenPeppers = Double.parseDouble(GreenText.getText());
        double BlackOlives = Double.parseDouble(BlackText.getText());
        double CanadianBacon = Double.parseDouble(CanadianText.getText());
        double Pineapple = Double.parseDouble(PineText.getText());
        double PizzaSauce = Double.parseDouble(SauceText.getText());
        double Cheese = Double.parseDouble(InventoryCheeseText.getText());
        try{
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();
            String truncate = "TRUNCATE TABLE inventory;";
            PreparedStatement truncateStmt = connectDB.prepareStatement(truncate);
            truncateStmt.execute();
            String updateinventory = "INSERT INTO inventory (InventoryID, dough, Pepperoni, PizzaSauce, Cheese, GreenPepper, BlackOlive, PineApple, CanadianBacon, Sausage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement preparedStmt = connectDB.prepareStatement(updateinventory);
            preparedStmt.setInt(1, 1);
            preparedStmt.setDouble(2, dough);
            preparedStmt.setDouble(3, Pepperoni);
            preparedStmt.setDouble(4, PizzaSauce);
            preparedStmt.setDouble(5, Cheese);
            preparedStmt.setDouble(6, GreenPeppers);
            preparedStmt.setDouble(7, BlackOlives);
            preparedStmt.setDouble(8, Pineapple);
            preparedStmt.setDouble(9, CanadianBacon);
            preparedStmt.setDouble(10, Sausage);

            preparedStmt.execute();
            connectDB.close();
        }
        catch(Exception e){
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }
    }

    @FXML
    void RemovePine(ActionEvent event) {
        double pine = Double.parseDouble(PineText.getText()) - 1;
        PineText.setText("" +pine+ "");
        double dough = Double.parseDouble(DoughText.getText());
        double Sausage = Double.parseDouble(InventorySausageText.getText());
        double Pepperoni = Double.parseDouble(InventoryPeppText.getText());
        double GreenPeppers = Double.parseDouble(GreenText.getText());
        double BlackOlives = Double.parseDouble(BlackText.getText());
        double CanadianBacon = Double.parseDouble(CanadianText.getText());
        double Pineapple = Double.parseDouble(PineText.getText());
        double PizzaSauce = Double.parseDouble(SauceText.getText());
        double Cheese = Double.parseDouble(InventoryCheeseText.getText());
        try{
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();
            String truncate = "TRUNCATE TABLE inventory;";
            PreparedStatement truncateStmt = connectDB.prepareStatement(truncate);
            truncateStmt.execute();
            String updateinventory = "INSERT INTO inventory (InventoryID, dough, Pepperoni, PizzaSauce, Cheese, GreenPepper, BlackOlive, PineApple, CanadianBacon, Sausage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement preparedStmt = connectDB.prepareStatement(updateinventory);
            preparedStmt.setInt(1, 1);
            preparedStmt.setDouble(2, dough);
            preparedStmt.setDouble(3, Pepperoni);
            preparedStmt.setDouble(4, PizzaSauce);
            preparedStmt.setDouble(5, Cheese);
            preparedStmt.setDouble(6, GreenPeppers);
            preparedStmt.setDouble(7, BlackOlives);
            preparedStmt.setDouble(8, Pineapple);
            preparedStmt.setDouble(9, CanadianBacon);
            preparedStmt.setDouble(10, Sausage);

            preparedStmt.execute();
            connectDB.close();
        }
        catch(Exception e){
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }
    }

    @FXML
    void RemoveSauce(ActionEvent event) {
        double Sauce = Double.parseDouble(SauceText.getText()) - 1;
        SauceText.setText("" +Sauce+ "");
        double dough = Double.parseDouble(DoughText.getText());
        double Sausage = Double.parseDouble(InventorySausageText.getText());
        double Pepperoni = Double.parseDouble(InventoryPeppText.getText());
        double GreenPeppers = Double.parseDouble(GreenText.getText());
        double BlackOlives = Double.parseDouble(BlackText.getText());
        double CanadianBacon = Double.parseDouble(CanadianText.getText());
        double Pineapple = Double.parseDouble(PineText.getText());
        double PizzaSauce = Double.parseDouble(SauceText.getText());
        double Cheese = Double.parseDouble(InventoryCheeseText.getText());
        try{
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();
            String truncate = "TRUNCATE TABLE inventory;";
            PreparedStatement truncateStmt = connectDB.prepareStatement(truncate);
            truncateStmt.execute();
            String updateinventory = "INSERT INTO inventory (InventoryID, dough, Pepperoni, PizzaSauce, Cheese, GreenPepper, BlackOlive, PineApple, CanadianBacon, Sausage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement preparedStmt = connectDB.prepareStatement(updateinventory);
            preparedStmt.setInt(1, 1);
            preparedStmt.setDouble(2, dough);
            preparedStmt.setDouble(3, Pepperoni);
            preparedStmt.setDouble(4, PizzaSauce);
            preparedStmt.setDouble(5, Cheese);
            preparedStmt.setDouble(6, GreenPeppers);
            preparedStmt.setDouble(7, BlackOlives);
            preparedStmt.setDouble(8, Pineapple);
            preparedStmt.setDouble(9, CanadianBacon);
            preparedStmt.setDouble(10, Sausage);

            preparedStmt.execute();
            connectDB.close();
        }
        catch(Exception e){
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }
    }
/////////////// This is the beginning of the code for the Time Clock
    @FXML
    private TextField HoursText;

    @FXML
    private TextField NextPayText;

    @FXML
    private TextField PayRateText;

    @FXML
    private Button Clockin;

    @FXML
    private Button ClockOut;
    @FXML
    public void ClockIn(ActionEvent event) {
        long startTime = System.currentTimeMillis()/1000;
        Clockin.setDisable(true);
        System.out.println(startTime);
         try {
             DatabaseConnection connectNow = new DatabaseConnection();
             Connection connectDB = connectNow.getConnection();
             String truncate = "TRUNCATE TABLE timestamp;";
             PreparedStatement truncateStmt = connectDB.prepareStatement(truncate);
             truncateStmt.execute();
             String Timestamp = "INSERT INTO timestamp (idtimestamp,clockin) VALUES (?, ?);";
             PreparedStatement ClockinStmt = connectDB.prepareStatement(Timestamp);
             ClockinStmt.setInt(1, 1);
             ClockinStmt.setLong(2, startTime);
             ClockinStmt.execute();
         }
         catch(Exception e){
             System.err.println("Got an exception!");
             // printStackTrace method
             // prints line numbers + call stack
             e.printStackTrace();
             // Prints what exception has been thrown
             System.out.println(e);
         }
    }

    public double HourlyRate = LoginController.CurrUser.getHourlyWage();
    @FXML
    public void ClockOut(ActionEvent event) {
        long timestamp = 0;
        try {
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();
            Statement stmt = connectDB.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM timestamp");
            timestamp = 0;
            while (rs.next()) {
                timestamp = rs.getLong("clockin");
            }

        } catch (Exception e) {
            System.err.println("Got an exception!");
            // printStackTrace method
            // prints line numbers + call stack
            e.printStackTrace();
            // Prints what exception has been thrown
            System.out.println(e);
        }
        long punchout = System.currentTimeMillis() / 1000;
        System.out.println(punchout);
        long total = punchout - timestamp;
        long fin = total / 60;
        System.out.println(total);
        HoursText.setText("" + fin + "");
        PayRateText.setText("$" + HourlyRate + "/hr");
        double TotalPay = (HourlyRate / 60) * fin;
        NextPayText.setText("$" + TotalPay + "");
        Clockin.setDisable(false);
    }

/////////////// This is the beginning of the code for the Postings




    // Define the Java object to hold the data retrieved from the MySQL database


}


