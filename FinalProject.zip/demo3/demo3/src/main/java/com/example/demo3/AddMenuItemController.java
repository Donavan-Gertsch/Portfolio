package com.example.demo3;

import java.util.List;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class AddMenuItemController {
    @FXML
    private TextField nameTextField;
    @FXML
    private TextArea descriptionTextArea;
    @FXML
    private TextArea ingredientsTextArea;
    @FXML
    private Button addButton;
    @FXML
    private Button deleteButton;
    @FXML
    private Button editButton;
    @FXML
    private TableView<MenuItem> menuItemTableView;
    @FXML
    private TableColumn<MenuItem, String> nameColumn;
    @FXML
    private TableColumn<MenuItem, String> descriptionColumn;
    @FXML
    private TableColumn<MenuItem, String> ingredientsColumn;
    private List<MenuItem> menuItems;
    private Stage dialogStage;
    private MenuItem selectedItem;

    public AddMenuItemController() {
    }

    public void setMenuItems(List<MenuItem> menuItems) {
        this.menuItems = menuItems;
        this.menuItemTableView.setItems(FXCollections.observableList(menuItems));
    }

    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    @FXML
    private void initialize() {
        this.nameColumn.setCellValueFactory((cellData) -> {
            return ((MenuItem)cellData.getValue()).nameProperty();
        });
        this.descriptionColumn.setCellValueFactory((cellData) -> {
            return ((MenuItem)cellData.getValue()).descriptionProperty();
        });
        this.ingredientsColumn.setCellValueFactory((cellData) -> {
            return ((MenuItem)cellData.getValue()).ingredientsProperty();
        });
        this.menuItemTableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                this.setSelectedMenuItem(newSelection);
            }

        });
    }

    private void setSelectedMenuItem(MenuItem menuItem) {
        this.selectedItem = menuItem;
        this.nameTextField.setText(menuItem.getName());
        this.descriptionTextArea.setText(menuItem.getDescription());
        this.ingredientsTextArea.setText(menuItem.getIngredients());
    }

    @FXML
    private void handleAddButton() {
        String name = this.nameTextField.getText();
        String description = this.descriptionTextArea.getText();
        String ingredients = this.ingredientsTextArea.getText();
        if (!name.isEmpty() && !description.isEmpty() && !ingredients.isEmpty()) {
            if (this.selectedItem != null) {
                this.selectedItem.setName(name);
                this.selectedItem.setDescription(description);
                this.selectedItem.setIngredients(ingredients);
                this.menuItemTableView.refresh();
            } else {
                MenuItem menuItem = new MenuItem(name, description, ingredients);
                this.menuItems.add(menuItem);
            }

            this.menuItemTableView.setItems(FXCollections.observableList(this.menuItems));
            this.clearFields();
        } else {
            Alert alert = new Alert(AlertType.ERROR);
            alert.initOwner(this.dialogStage);
            alert.setTitle("Invalid Fields");
            alert.setHeaderText("Please correct invalid fields");
            alert.setContentText("All fields are required");
            alert.showAndWait();
        }
    }

    @FXML
    private void handleDeleteButton() {
        MenuItem selectedItem = (MenuItem)this.menuItemTableView.getSelectionModel().getSelectedItem();
        if (selectedItem != null) {
            this.menuItems.remove(selectedItem);
            this.menuItemTableView.setItems(FXCollections.observableList(this.menuItems));
            this.clearFields();
        } else {
            Alert alert = new Alert(AlertType.WARNING);
            alert.initOwner(this.dialogStage);
            alert.setTitle("No Selection");
            alert.setHeaderText("No menu item selected");
            alert.setContentText("Please select a menu item to delete.");
            alert.showAndWait();
        }

    }

    @FXML
    private void handleEditButton() {
        MenuItem selectedItem = (MenuItem)this.menuItemTableView.getSelectionModel().getSelectedItem();
        if (selectedItem != null) {
            this.setSelectedMenuItem(selectedItem);
            this.addButton.setText("Update");
        } else {
            Alert alert = new Alert(AlertType.WARNING);
            alert.initOwner(this.dialogStage);
            alert.setTitle("No Selection");
            alert.setHeaderText("No menu item selected");
            alert.setContentText("Please select a menu item to edit.");
            alert.showAndWait();
        }

    }

    @FXML
    private void handleCancelButton() {
        this.dialogStage.close();
    }

    private void clearFields() {
        this.nameTextField.setText("");
        this.descriptionTextArea.setText("");
        this.ingredientsTextArea.setText("");
        this.selectedItem = null;
        this.addButton.setText("Add");
    }
}
