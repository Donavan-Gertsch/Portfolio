import java.util.Random;
class Main {
  public static void main(String[] args) {

int dy1,dy2; // These two int values will represent the two rolled dice
int sum=0;// This value is equal to the final value of the combined two dice
int Total[]=new int[13];// This value is to create the tabular expression
int value;

for(value=0;value<13;value++){
  Total[value]=0;


  for(value=1;value<=36000000;value++){

    dy1= new Random().nextInt(6 - 1 + 1) + 1;// Simulation of first dice roll
    dy2= new Random().nextInt(6 - 1 + 1) + 1;// Simulation of second dice roll

    sum=dy1+dy2;

    Total[sum]++; // To add the outcome data to a subset within the array

}

  for(value=2;value<=12;value++){
    System.out.println("The number of times the dice combined value was "+value+"\nis equal to "+Total[value]);}
}
}
}
