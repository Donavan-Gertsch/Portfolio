package com.example.demo3;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

public class DataStore {
    private static DataStore instance;
    private List<Employee> employees = new ArrayList();
    private List<MenuItem> menuItems = new ArrayList();
    private List<Schedule> schedules = new ArrayList();
    private List<Sale> sales = new ArrayList();
    private List<String> weeks = new ArrayList();

    private DataStore() {
        this.populateSampleData();
        System.out.println("DataStore initialized.");
    }

    public static DataStore getInstance() {
        if (instance == null) {
            instance = new DataStore();
            System.out.println("DataStore instance created.");
        }

        return instance;
    }

    private void populateSampleData() {
        this.employees.add(new Employee("John", "Doe", "Manager"));
        this.employees.add(new Employee("Jane", "Smith", "Cashier"));
        this.employees.add(new Employee("Mike", "Johnson", "Cook"));
        this.menuItems.add(new MenuItem("Pepperoni Pizza", "A delicious pepperoni pizza with mozzarella cheese", "Pepperoni, Mozzarella, Tomato Sauce"));
        this.menuItems.add(new MenuItem("Veggie Pizza", "A pizza loaded with fresh vegetables", "Bell Peppers, Onions, Mushrooms, Olives, Tomato Sauce"));
        this.menuItems.add(new MenuItem("Margherita Pizza", "A classic pizza with tomato sauce, mozzarella, and basil", "Mozzarella, Tomato Sauce, Basil"));
        this.menuItems.add(new MenuItem("BBQ Chicken Pizza", "A pizza topped with BBQ sauce, chicken, and red onions", "BBQ Sauce, Chicken, Mozzarella, Red Onions"));
        this.menuItems.add(new MenuItem("Spinach and Feta Pizza", "A pizza with spinach, feta cheese, and garlic", "Spinach, Feta Cheese, Garlic, Mozzarella"));
        this.menuItems.add(new MenuItem("Meat Lovers Pizza", "A pizza loaded with meat toppings like sausage, pepperoni, and ham", "Sausage, Pepperoni, Ham, Mozzarella, Tomato Sauce"));
        LocalDate today = LocalDate.now();
        this.schedules.add(new Schedule((Employee)this.employees.get(0), today, LocalTime.of(9, 0), LocalTime.of(17, 0)));
        this.schedules.add(new Schedule((Employee)this.employees.get(1), today, LocalTime.of(10, 0), LocalTime.of(18, 0)));
        this.schedules.add(new Schedule((Employee)this.employees.get(2), today, LocalTime.of(11, 0), LocalTime.of(19, 0)));
        Random random = new Random();

        for(int i = 0; i < 7; ++i) {
            double revenue = 1000.0 + random.nextDouble() * 500.0;
            double expenses = 800.0 + random.nextDouble() * 300.0;
            this.sales.add(new Sale(today.minusDays((long)i), revenue, expenses));
        }

        this.weeks.add("Week 1");
        this.weeks.add("Week 2");
        this.weeks.add("Week 3");
        this.weeks.add("Week 4");
    }

    public List<String> getWeeks() {
        return this.weeks;
    }

    public void addEmployee(Employee employee) {
        this.employees.add(employee);
    }

    public List<Employee> getEmployees() {
        return this.employees;
    }

    public void addSchedule(Schedule schedule) {
        this.schedules.add(schedule);
    }

    public void removeSchedule(Schedule schedule) {
        this.schedules.remove(schedule);
    }

    public void addMenuItem(MenuItem menuItem) {
        this.menuItems.add(menuItem);
    }

    public void removeMenuItem(MenuItem menuItem) {
        this.menuItems.remove(menuItem);
    }

    public List<MenuItem> getMenuItems() {
        return this.menuItems;
    }

    public List<Schedule> getSchedules() {
        return this.schedules;
    }

    public List<Sale> getSales() {
        return this.sales;
    }

    public MenuItem findMenuItemByName(String name) {
        Iterator var3 = this.menuItems.iterator();

        while(var3.hasNext()) {
            MenuItem item = (MenuItem)var3.next();
            if (item.getName().equals(name)) {
                return item;
            }
        }

        return null;
    }

    public Map<String, Double> getSalesDataForWeek(String week) {
        Map<String, Double> salesData = new HashMap();
        if (week.equals("Week 1")) {
            salesData.put("Monday", 1000.0);
            salesData.put("Tuesday", 1500.0);
            salesData.put("Wednesday", 1200.0);
            salesData.put("Thursday", 1300.0);
            salesData.put("Friday", 1800.0);
            salesData.put("Saturday", 2000.0);
            salesData.put("Sunday", 1900.0);
        } else if (week.equals("Week 2")) {
            salesData.put("Monday", 1200.0);
            salesData.put("Tuesday", 1300.0);
            salesData.put("Wednesday", 1500.0);
            salesData.put("Thursday", 1400.0);
            salesData.put("Friday", 1700.0);
            salesData.put("Saturday", 1900.0);
            salesData.put("Sunday", 2000.0);
        } else if (week.equals("Week 3")) {
            salesData.put("Monday", 1100.0);
            salesData.put("Tuesday", 1600.0);
            salesData.put("Wednesday", 1300.0);
            salesData.put("Thursday", 1400.0);
            salesData.put("Friday", 1500.0);
            salesData.put("Saturday", 1800.0);
            salesData.put("Sunday", 1900.0);
        } else if (week.equals("Week 4")) {
            salesData.put("Monday", 1000.0);
            salesData.put("Tuesday", 1300.0);
            salesData.put("Wednesday", 1500.0);
            salesData.put("Thursday", 1400.0);
            salesData.put("Friday", 1600.0);
            salesData.put("Saturday", 2000.0);
            salesData.put("Sunday", 1800.0);
        }

        return salesData;
    }

    public Map<String, Double> getExpensesDataForWeek(String week) {
        Map<String, Double> expensesData = new HashMap();
        if (week.equals("Week 1")) {
            expensesData.put("Monday", 500.0);
            expensesData.put("Tuesday", 700.0);
            expensesData.put("Wednesday", 400.0);
            expensesData.put("Thursday", 800.0);
            expensesData.put("Friday", 900.0);
            expensesData.put("Saturday", 1000.0);
        } else if (week.equals("Week 2")) {
            expensesData.put("Monday", 600.0);
            expensesData.put("Tuesday", 500.0);
            expensesData.put("Wednesday", 700.0);
            expensesData.put("Thursday", 900.0);
            expensesData.put("Friday", 800.0);
            expensesData.put("Saturday", 1100.0);
            expensesData.put("Sunday", 1000.0);
        } else if (week.equals("Week 3")) {
            expensesData.put("Monday", 700.0);
            expensesData.put("Tuesday", 800.0);
            expensesData.put("Wednesday", 400.0);
            expensesData.put("Thursday", 900.0);
            expensesData.put("Friday", 700.0);
            expensesData.put("Saturday", 1200.0);
            expensesData.put("Sunday", 1100.0);
        } else if (week.equals("Week 4")) {
            expensesData.put("Monday", 500.0);
            expensesData.put("Tuesday", 700.0);
            expensesData.put("Wednesday", 600.0);
            expensesData.put("Thursday", 800.0);
            expensesData.put("Friday", 900.0);
            expensesData.put("Saturday", 1000.0);
            expensesData.put("Sunday", 1100.0);
        }

        return expensesData;
    }
}