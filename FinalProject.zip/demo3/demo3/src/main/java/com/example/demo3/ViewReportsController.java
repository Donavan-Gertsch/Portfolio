package com.example.demo3;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;

public class ViewReportsController {
    @FXML
    private ComboBox<String> weekComboBox;
    @FXML
    private BarChart<String, Number> salesBarChart;

    public ViewReportsController() {
    }

    @FXML
    public void initialize() {
        this.populateWeeks();
        this.weekComboBox.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
            this.updateChartData(newValue);
        });
    }

    private void populateWeeks() {
        List<String> weeks = DataStore.getInstance().getWeeks();
        this.weekComboBox.setItems(FXCollections.observableArrayList(weeks));
    }

    private void updateChartData(String week) {
        this.salesBarChart.getData().clear();
        Map<String, Double> salesData = DataStore.getInstance().getSalesDataForWeek(week);
        Map<String, Double> expensesData = DataStore.getInstance().getExpensesDataForWeek(week);
        XYChart.Series<String, Number> salesSeries = new XYChart.Series();
        salesSeries.setName("Weekly Sales");
        Iterator var6 = salesData.entrySet().iterator();

        while(var6.hasNext()) {
            Map.Entry<String, Double> entry = (Map.Entry)var6.next();
            salesSeries.getData().add(new XYChart.Data((String)entry.getKey(), (Number)entry.getValue()));
        }

        XYChart.Series<String, Number> expensesSeries = new XYChart.Series();
        expensesSeries.setName("Weekly Expenses");
        Iterator var7 = expensesData.entrySet().iterator();

        while(var7.hasNext()) {
            Map.Entry<String, Double> entry = (Map.Entry)var7.next();
            expensesSeries.getData().add(new XYChart.Data((String)entry.getKey(), (Number)entry.getValue()));
        }

        this.salesBarChart.getData().addAll(new XYChart.Series[]{salesSeries, expensesSeries});
    }

    @FXML
    void goBack(ActionEvent event) throws IOException {
        Stage stage = (Stage)this.weekComboBox.getScene().getWindow();
        Parent root = (Parent)FXMLLoader.load(this.getClass().getResource("MainMenu.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}