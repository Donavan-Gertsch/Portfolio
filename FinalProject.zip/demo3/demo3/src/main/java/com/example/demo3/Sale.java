package com.example.demo3;

import java.time.LocalDate;

public class Sale {
    private LocalDate date;
    private double revenue;
    private double expenses;

    public Sale(LocalDate date, double revenue, double expenses) {
        this.date = date;
        this.revenue = revenue;
        this.expenses = expenses;
    }

    public LocalDate getDate() {
        return this.date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public double getRevenue() {
        return this.revenue;
    }

    public void setRevenue(double revenue) {
        this.revenue = revenue;
    }

    public double getExpenses() {
        return this.expenses;
    }

    public void setExpenses(double expenses) {
        this.expenses = expenses;
    }
}