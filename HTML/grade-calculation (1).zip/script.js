function calc()
  {
var x=document.getElementById('tempbox').value;

y=document.getElementById('humiditybox').value;

var dewpoint= x-((100-y)/2.7778);
  }