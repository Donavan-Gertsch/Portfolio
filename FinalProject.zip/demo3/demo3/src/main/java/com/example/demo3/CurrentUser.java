package com.example.demo3;

public class CurrentUser {
    public String Username;
    public Boolean Manager;
    public Double HourlyWage;
    public CurrentUser(String Username,Boolean Manager,Double hourlywage){
        this.Username = Username;
        this.Manager = Manager;
        this.HourlyWage = hourlywage;
    }
    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public Boolean getManager() {
        return Manager;
    }

    public void setManager(boolean Manager) {
        this.Manager = Manager;
    }

    public Double getHourlyWage() {
        return this.HourlyWage;
    }

    public void setHourlyWage(double HourlyWage) {
        this.HourlyWage = HourlyWage;
    }
}
