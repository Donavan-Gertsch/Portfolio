let broll = document.getElementById('roll');
let bir = document.getElementById('iroll');
let reset = document.getElementById('reset')
var d1 = Math.floor((Math.random()*6) +1);
var d2 = Math.floor((Math.random()*6) +1);
var troll = d1+d2;


function ir()
  {
  document.getElementById("ir").innerHTML= 'Players Point: ' + troll;
    
  if(troll == 7 || troll == 11){
	
		document.getElementById("outputDIV").innerHTML= 'Winner ' + troll;
	}
  else if (troll == 2 || troll == 3){
    document.getElementById("outputDIV").innerHTML= 'Loser ' + troll;
  }
  bir.disabled = true;
  broll.disabled = false;
  }

function roll()
{
if(troll != troll || troll!= 7){
var d3 = Math.floor((Math.random()*6) +1);
var d4 = Math.floor((Math.random()*6) +1);
var reroll = d3+d4;
document.getElementById("outputDIV").innerHTML= reroll;
}
if (troll==reroll){
  document.getElementById("outputDIV").innerHTML= 'Winner ' + reroll;
  broll.disabled = true;
  reset.disabled = false;
  alert("Winner");
}
else if(reroll==7){
  document.getElementById("outputDIV").innerHTML= 'Loser ' + reroll;
  broll.disabled = true;
  reset.disabled = false;
  alert("Loser");
}
  

}
function rs()
{
document.getElementById("ir").innerHTML= 'Players Point: ';
document.getElementById("outputDIV").innerHTML= '';
bir.disabled = false;
reset.disabled = true;

}