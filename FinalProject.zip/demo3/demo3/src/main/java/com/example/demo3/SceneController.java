package com.example.demo3;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;
import java.util.Objects;

public class SceneController{
        public SceneController (AnchorPane currentAnchorPane, String fxml ) throws IOException {
                AnchorPane nextAnchorPane = FXMLLoader.load(Objects.requireNonNull(HelloApplication.class.getResource(fxml)));
                currentAnchorPane.getChildren().removeAll();
                currentAnchorPane.getChildren().setAll(nextAnchorPane);
                
        }
        }
