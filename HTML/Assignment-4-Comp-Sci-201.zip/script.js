
      function rhino()
      {
        document.getElementById("random").src= "./Zoo/Rhino.jpg";
      }
      function elephant()
      {
        document.getElementById("random").src= "./Zoo/Elephant.jpg";
      }   
      function gorilla()
      {
        document.getElementById("random").src= "./Zoo/Gorilla.jpg";
      }   
      function hippo()
      {
        document.getElementById("random").src= "./Zoo/Hippo.jpg";
      }  
      function tiger()
      {
        document.getElementById("random").src= "./Zoo/Tiger.jpg";
      }
      function lion()
      {
        document.getElementById("random").src= "./Zoo/Lion.jpg";
      }
      function help()
      {
        document.getElementById('help').innerHTML='Please report any problems you have with this site to,'+' <i>gertdd08@uwgb.edu<i>.';
      }
      function message()
      {
        document.getElementById('help').innerHTML='Need Help?';
      }
      function reset()
      {
        window.location.reload();
      } 
