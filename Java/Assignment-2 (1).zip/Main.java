import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.print("Enter 5 Numbers");
      int string = input.nextInt();
      int n1 = string / 10000 % 10;
      int n2 = string / 1000 % 10;
      int n3 = string / 100 % 10;
      int n4 = string / 10 % 10;
      int n5 = string / 1 % 10;
    System.out.println(n1 + " " + n2 + " " + n3 + " " + n4 + " " + n5 + " ");
    input.close();
  }
}