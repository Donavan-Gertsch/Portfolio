  function BusSongVerse(object,action)
    {
     document.getElementById('outputDIV').innerHTML = 'The ' + object + ' on the bus go ' + action + '<br> ' + action + '<br> ' + action + '<br> ' + "The " + object + ' on the bus go ' + action + '<br>all day long.';
    }