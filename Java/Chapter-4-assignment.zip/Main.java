import java.util.*;

class Main {

public static void main(String[] args) {

Scanner input=new Scanner(System.in);

//Initialization Process//
  
System.out.println("How many numbers are you comparing?");
  int numbers;

numbers = input.nextInt();
  int arr[] = new int [numbers];
  
  //Number collection process//
  
  int counter=0,number,largest=0,nc=1;

while (counter < numbers)
  {
    System.out.println("Enter number " + nc );
      number = input.nextInt();
      arr[counter]=number;
    if(number>largest)
      largest=number;
      counter++;
      nc++;
  }
  System.out.println("The highest value is "+largest);
}
}