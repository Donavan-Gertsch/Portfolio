package com.example.demo3;

import java.time.LocalDate;
import java.time.LocalTime;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class SetScheduleController {
    @FXML
    private ComboBox<Employee> employeeComboBox;
    @FXML
    private DatePicker scheduleDatePicker;
    @FXML
    private ComboBox<LocalTime> startTimeComboBox;
    @FXML
    private ComboBox<LocalTime> endTimeComboBox;
    private ManageScheduleController manageSchedulesController;

    public SetScheduleController() {
    }

    public void initialize() {
        this.employeeComboBox.setItems(FXCollections.observableArrayList(DataStore.getInstance().getEmployees()));
        this.initTimeComboBoxes();
    }

    public void initialize(Schedule schedule) {
        this.initialize();
        this.employeeComboBox.setValue(schedule.getEmployee());
        this.scheduleDatePicker.setValue(schedule.getDate());
        this.startTimeComboBox.setValue(schedule.getStartTime());
        this.endTimeComboBox.setValue(schedule.getEndTime());
    }

    public void setManageSchedulesController(ManageScheduleController manageSchedulesController) {
        this.manageSchedulesController = manageSchedulesController;
    }

    private void initTimeComboBoxes() {
        ObservableList<LocalTime> times = FXCollections.observableArrayList();

        for(int i = 0; i < 24; ++i) {
            times.add(LocalTime.of(i, 0));
            times.add(LocalTime.of(i, 30));
        }

        this.startTimeComboBox.setItems(times);
        this.endTimeComboBox.setItems(times);
    }

    @FXML
    private void handleSaveScheduleButton(ActionEvent event) {
        Employee employee = (Employee)this.employeeComboBox.getSelectionModel().getSelectedItem();
        LocalDate date = (LocalDate)this.scheduleDatePicker.getValue();
        LocalTime startTime = (LocalTime)this.startTimeComboBox.getSelectionModel().getSelectedItem();
        LocalTime endTime = (LocalTime)this.endTimeComboBox.getSelectionModel().getSelectedItem();
        if (employee != null && date != null && startTime != null && endTime != null) {
            Schedule schedule = new Schedule(employee, date, startTime, endTime);
            this.manageSchedulesController.addSchedule(schedule);
            Stage stage = (Stage)this.startTimeComboBox.getScene().getWindow();
            stage.close();
        } else {
            this.showErrorDialog("All fields must be filled in.");
        }
    }

    private void showErrorDialog(String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText((String)null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

