package com.example.demo3;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class AddEmployeeController {
    @FXML
    private TextField firstNameField;
    @FXML
    private TextField lastNameField;
    @FXML
    private TextField positionField;
    @FXML
    private TableView<Employee> employeeTable;
    @FXML
    private TableColumn<Employee, String> firstNameColumn;
    @FXML
    private TableColumn<Employee, String> lastNameColumn;
    @FXML
    private TableColumn<Employee, String> positionColumn;
    @FXML
    private Label selectedFirstNameLabel;
    @FXML
    private Label selectedLastNameLabel;
    @FXML
    private Label selectedPositionLabel;
    @FXML
    private Button editButton;
    @FXML
    private Button deleteButton;
    private ObservableList<Employee> employeeList;

    public AddEmployeeController() {
    }

    @FXML
    public void initialize() {
        this.firstNameColumn.setCellValueFactory(new PropertyValueFactory("firstName"));
        this.lastNameColumn.setCellValueFactory(new PropertyValueFactory("lastName"));
        this.positionColumn.setCellValueFactory(new PropertyValueFactory("position"));
        this.employeeList = FXCollections.observableArrayList(DataStore.getInstance().getEmployees());
        this.employeeTable.setItems(this.employeeList);
        this.employeeTable.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            this.showEmployeeDetails(newValue);
        });
    }

    @FXML
    private void addEmployee() {
        String firstName = this.firstNameField.getText();
        String lastName = this.lastNameField.getText();
        String position = this.positionField.getText();
        Employee newEmployee = new Employee(firstName, lastName, position);
        DataStore.getInstance().addEmployee(newEmployee);
        this.firstNameField.clear();
        this.lastNameField.clear();
        this.positionField.clear();
        this.employeeList.add(newEmployee);
    }

    @FXML
    private void editEmployee() {
        Employee selectedEmployee = (Employee)this.employeeTable.getSelectionModel().getSelectedItem();
        if (selectedEmployee != null) {
            selectedEmployee.setFirstName(this.selectedFirstNameLabel.getText());
            selectedEmployee.setLastName(this.selectedLastNameLabel.getText());
            selectedEmployee.setPosition(this.selectedPositionLabel.getText());
            this.employeeTable.refresh();
        }

    }

    @FXML
    private void deleteEmployee() {
        Employee selectedEmployee = (Employee)this.employeeTable.getSelectionModel().getSelectedItem();
        if (selectedEmployee != null) {
            DataStore.getInstance().getEmployees().remove(selectedEmployee);
            this.employeeList.remove(selectedEmployee);
        }

    }

    private void showEmployeeDetails(Employee employee) {
        if (employee != null) {
            this.selectedFirstNameLabel.setText(employee.getFirstName());
            this.selectedLastNameLabel.setText(employee.getLastName());
            this.selectedPositionLabel.setText(employee.getPosition());
            this.editButton.setDisable(false);
            this.deleteButton.setDisable(false);
        } else {
            this.selectedFirstNameLabel.setText("");
            this.selectedLastNameLabel.setText("");
            this.selectedPositionLabel.setText("");
            this.editButton.setDisable(true);
            this.deleteButton.setDisable(true);
        }

    }
}
