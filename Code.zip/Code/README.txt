Inside the data folder you will find four different files. To use these files simply place them within the directory you are
running the code in so that the program can access them when it needs to. The chess.pgn file is the dataset of chess games
that the initial convolutional nueral network is run on. Inside the chess_modle_weights is a set of weights that is generated
from the initial convolutional nueral network. Having this file in the directory will allow you to bypass the training of the
initial model. The file chess_model_weights_final is a file that contains the final weights after the self play loop
**The self play loop can take up to 30 minutes so please simply skip this training time and use the afromentioned file**
this will allow you to play a game against the model without having to train the model via the self play loop. Finally the
**stockfish-unbuntu file is a tarfile that requires a specific py snippet to be ran. This snippet has the comment #Stockfish**
with these these files in place you should be able to play a game against the model.