import java.util.*;
class Main {
  public static void main(String[] args) {
    Scanner input=new Scanner(System.in);
    int z = 2;
  while(z>1){
    System.out.println("Guess a number between 1 and 1000");
    int x = 0;
    var number= Math.floor(Math.random()*(1000-1+1)+1) ;
    while(x<1){
      int guess = input.nextInt();
        if(guess<number){ System.out.println("Too low. Try again.");}
        if(guess>number){System.out.println("Too high. Try again.");}
        if(guess==number){System.out.println("Congratulations. You guessed the number!"); x++;}
    }
          System.out.println("Press 1 to play again or Press 2 to not play again");
    int y=0;
    while(y<1){
    int repeat = input.nextInt();
    if(repeat==1){y++;}
    if(repeat==2){z=0;}
    }
  }
  }
}