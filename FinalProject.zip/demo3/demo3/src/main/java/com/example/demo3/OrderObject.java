package com.example.demo3;

public class OrderObject extends DirectoryController{
    private int theOrderID;
    private String name;
    private int pepperoni;
    private int sausage;
    private int cheese;
    private int hawian;
    private int work;
    private double total;

    public OrderObject(int theOrderID, String name, int pepperoni, int sausage, int work, int hawian, int cheese, double total) {
        super();
        this.theOrderID = theOrderID;
        this.name = name;
        this.pepperoni = pepperoni;
        this.sausage = sausage;
        this.cheese = cheese;
        this.hawian = hawian;
        this.work = work;
        this.total = total;

    }
    public int gettheOrderID() {
        return theOrderID;
    }

    public void setTheOrderID(int theOrderID) {
        this.theOrderID = theOrderID;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPepperoni() {
        return pepperoni;
    }

    public void setPepperoni(int pepperoni) {
        this.pepperoni = pepperoni;
    }

    public int getOrderID() {
        return theOrderID;
    }

    public void setOrderID(int orderID) {
        this.theOrderID = orderID;
    }

    public int getSausage() {
        return sausage;
    }

    public void setSausage(int sausage) {
        this.sausage = sausage;
    }

    public int getCheese() {
        return cheese;
    }

    public void setCheese(int cheese) {
        this.cheese = cheese;
    }

    public int getHawian() {
        return hawian;
    }

    public void setHawian(int hawian) {
        this.hawian = hawian;
    }

    public int getWork() {
        return work;
    }

    public void setWork(int work) {
        this.work = work;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
}
