class Main {
  public static void main(String[] args) {
int x = 1;
for (int q=0; q<10; q++)
{
  for(int b=0; b<x; b++){
    System.out.print('*');
    }
  System.out.println();
  x++;  
}
int b = 10;
    for (int c=0; c<10; c++)
{
  for(int d=0; d<b; d++){
    System.out.print('*');
    }
  System.out.println();
  b--;  
}

} 
}


