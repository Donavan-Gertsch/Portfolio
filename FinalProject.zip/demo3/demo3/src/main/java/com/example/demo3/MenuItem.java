package com.example.demo3;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class MenuItem {
    private String name;
    private String description;
    private String ingredients;

    public MenuItem(String name, String description, String ingredients) {
        this.name = name;
        this.description = description;
        this.ingredients = ingredients;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return this.description;
    }

    public StringProperty nameProperty() {
        return new SimpleStringProperty(this.name);
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getIngredients() {
        return this.ingredients;
    }

    public void setIngredients(String ingredients) {
        this.ingredients = ingredients;
    }

    public StringProperty ingredientsProperty() {
        return new SimpleStringProperty(this.ingredients);
    }

    public StringProperty descriptionProperty() {
        return new SimpleStringProperty(this.description);
    }

    public String toString() {
        return this.name + " - " + this.description;
    }
}

