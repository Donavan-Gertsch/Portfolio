package com.example.demo3;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ManageScheduleController {
    @FXML
    private ComboBox<Employee> employeeComboBox;
    @FXML
    private TableView<Schedule> scheduleTable;
    @FXML
    private TableColumn<Schedule, Employee> scheduleEmployeeColumn;
    @FXML
    private TableColumn<Schedule, LocalDate> scheduleDateColumn;
    @FXML
    private TableColumn<Schedule, LocalTime> scheduleStartTimeColumn;
    @FXML
    private TableColumn<Schedule, LocalTime> scheduleEndTimeColumn;

    public ManageScheduleController() {
    }

    @FXML
    public void initialize() {
        this.employeeComboBox.setItems(FXCollections.observableArrayList(DataStore.getInstance().getEmployees()));
        System.out.println("Schedules: " + DataStore.getInstance().getSchedules());
        this.scheduleTable.setItems(FXCollections.observableArrayList(DataStore.getInstance().getSchedules()));
        this.scheduleTable.setItems(FXCollections.observableArrayList(DataStore.getInstance().getSchedules()));
        this.scheduleEmployeeColumn.setCellValueFactory(new PropertyValueFactory("employee"));
        this.scheduleDateColumn.setCellValueFactory(new PropertyValueFactory("date"));
        this.scheduleStartTimeColumn.setCellValueFactory(new PropertyValueFactory("startTime"));
        this.scheduleEndTimeColumn.setCellValueFactory(new PropertyValueFactory("endTime"));
    }

    @FXML
    private void handleAddScheduleButton(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(this.getClass().getResource("SetSchedule.fxml"));
        Parent root = (Parent)loader.load();
        SetScheduleController setScheduleController = (SetScheduleController)loader.getController();
        setScheduleController.setManageSchedulesController(this);
        setScheduleController.initialize();
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    private void handleEditScheduleButton(ActionEvent event) throws IOException {
        Schedule selectedSchedule = (Schedule)this.scheduleTable.getSelectionModel().getSelectedItem();
        if (selectedSchedule != null) {
            FXMLLoader loader = new FXMLLoader(this.getClass().getResource("SetSchedule.fxml"));
            Parent root = (Parent)loader.load();
            SetScheduleController setScheduleController = (SetScheduleController)loader.getController();
            setScheduleController.setManageSchedulesController(this);
            setScheduleController.initialize(selectedSchedule);
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.show();
        }

    }

    @FXML
    private void handleDeleteScheduleButton(ActionEvent event) {
        Schedule selectedSchedule = (Schedule)this.scheduleTable.getSelectionModel().getSelectedItem();
        if (selectedSchedule != null) {
            DataStore.getInstance().removeSchedule(selectedSchedule);
            this.scheduleTable.setItems(FXCollections.observableArrayList(DataStore.getInstance().getSchedules()));
        }

    }

    public void addSchedule(Schedule schedule) {
        DataStore.getInstance().addSchedule(schedule);
        this.scheduleTable.setItems(FXCollections.observableArrayList(DataStore.getInstance().getSchedules()));
    }
}

