function color()
{
document.getElementById('color').value
}
function proto()
{
  document.getElementById('proto').value
}
function size()
{
  document.getElementById('size').value
}
function speed()
{
  document.getElementById('speed').value
}
function generate()
{
  
}
